<!-- BEGIN: Content-->
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        <div class="content-body">
            <!-- merchant maps Start -->
            <section id="gmaps-basic-maps">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Merchant Maps</h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div id="mapmerchant" style="width: 100%; height: 800px;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- end of merchant maps -->
        </div>
    </div>
</div>

<!-- END: Content-->